import os
import time
from pynput import keyboard
from pynput.keyboard import Key, KeyCode

# State
listening = True
listener = None
pressed = set()
log = []

script_dir = os.path.dirname(os.path.abspath(__file__))


def save_log():
    """Save the logged keys to a new .txt file in the script directory."""
    timestamp = int(time.time())
    filename = os.path.join(script_dir, f"keylog_{timestamp}.txt")
    try:
        with open(filename, "w", encoding="utf-8") as f:
            f.write("".join(log))
        print(f"\nLog saved to {filename}")
    except Exception as e:
        print(f"Failed to save log: {e}")


def is_ctrl_pressed():
    return any(k in pressed for k in (Key.ctrl, Key.ctrl_l, Key.ctrl_r))


def on_press(key):
    global listening, listener
    pressed.add(key)

    # Handle hotkeys (Ctrl+I to toggle listening, Ctrl+O to stop and save)
    try:
        if isinstance(key, KeyCode) and key.char:
            ch = key.char.lower()
            if ch == "i" and is_ctrl_pressed():
                listening = not listening
                print(f"\nListening: {listening}")
                return
            if ch == "o" and is_ctrl_pressed():
                print("\nStopping and writing log...")
                save_log()
                if listener:
                    listener.stop()
                return
    except Exception:
        # ignore keys without char
        pass

    # If not listening, ignore other keys
    if not listening:
        return

    # Log printable chars
    if isinstance(key, KeyCode):
        ch = key.char
        if ch is not None:
            log.append(ch)
            print(ch, end="", flush=True)
    else:
        # Log special keys in brackets
        name = str(key)
        log.append(f"[{name}]")
        print(f"[{name}]", end="", flush=True)


def on_release(key):
    if key in pressed:
        pressed.remove(key)


if __name__ == "__main__":
    print("Keylogger started.")
    print("  Ctrl+I → toggle listening on/off")
    print("  Ctrl+O → stop, save log, and exit")
    print("-" * 40)
    with keyboard.Listener(on_press=on_press, on_release=on_release) as l:
        listener = l
        l.join()
    # Keep the terminal open after stopping so the user can read the output
    print("\nKeylogger stopped.")
    input("Press Enter to close this window...")
