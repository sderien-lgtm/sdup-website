import random

GREEN = "\033[32m"
YELLOW = "\033[33m"
GREY = "\033[90m"
RESET = "\033[0m"

print('Welcome to Wordle by Simon.')
print('This version of Wordle is not only made up of 5 letter words.')
print('If the letter is ' + GREEN + 'green, ' + RESET + 'then the letter is in the right spot.')
print('If the letter is ' + YELLOW + 'yellow, ' + RESET + 'then the letter is in the word, but not the right spot.')
print('If the letter is in its default colour, then the letter is not part of the secret word.')
print('You have 6 tries to find the final word.')

possiblewords = ['apple', 'tree', 'cat', 'dog', 'mouse', 'teacher', 'school', 'book', 'read', 'game', 'play',
                'friend', 'computer', 'python']

print('')

secret_word = random.choice(possiblewords)
word_preview = "'_'" * len(secret_word)

print('The secret word has ' + str(len(secret_word)) + ' letters.')
print(word_preview)

print('')

wordGuessed = False
attempts = 0

while not wordGuessed and attempts < 6:
    guess = input('Your guesss: ').lower()

    if len(guess) != len(secret_word):
        print('Your guess must be ', len(secret_word), " letters.")
        continue

    coloured_output = ""

    for i in range(len(secret_word)):
        if guess[i] == secret_word[i]:
            coloured_output += GREEN + guess[i] + RESET
        elif guess[i] in secret_word:
            coloured_output += YELLOW + guess[i] + RESET
        else:
            coloured_output += GREY + guess[i] + RESET
    
    print(coloured_output)

    attempts += 1

    if guess == secret_word:
        wordGuessed = True
        print(GREEN + 'You guessed the word!' + RESET)

if not wordGuessed:
    print('Out of tries! The word was ' + secret_word + '.')


#possiblewords = list of the word that you can randomly get
#secret_word = the word that was randomly chosen out of that list
#word_preview = a blank word consisting of just '_' to display how many letters are in the secret_word