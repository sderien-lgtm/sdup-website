import webbrowser
import random
import time
import subprocess
import platform

current_os = platform.system()  # 'Darwin' = macOS, 'Windows' = Windows, 'Linux' = Linux

safari = webbrowser.get('safari') if current_os == 'Darwin' else None
chrome = webbrowser.get('chrome')

print('=' * 30)
print('Welcome to tab opener by Simon.')
print('URL is set to default as wikipedia.')
print('=' * 30)
print('')

print('Which browser would you like to use?')
print('[1] Chrome')
if current_os == 'Darwin':
    print('[2] Safari')
else:
    print('[2] Edge')
browserChoice = int(input('Select [1-2]: '))

if browserChoice not in [1, 2]:
    print('INVALID CHOICE.')
    exit()

url = ['https://wikipedia.com']

# Running counters for the status bar
tabs_opened = 0
windows_opened = 0


def get_ram_usage():
    """Returns (used_gb, total_gb, percent) using only built-in OS tools — no pip installs needed."""
    try:
        if current_os == 'Darwin':
            total_bytes = int(subprocess.check_output(['sysctl', '-n', 'hw.memsize']).strip())

            vm_output = subprocess.check_output(['vm_stat']).decode()
            page_size = 4096
            lines = vm_output.splitlines()
            for line in lines:
                if 'page size of' in line:
                    page_size = int(line.split('page size of')[1].strip().split(' ')[0])

            stats = {}
            for line in lines:
                if ':' in line:
                    key, val = line.split(':')
                    val = val.strip().rstrip('.')
                    if val.isdigit():
                        stats[key.strip()] = int(val)

            used_pages = (stats.get('Pages active', 0) +
                          stats.get('Pages wired down', 0) +
                          stats.get('Pages occupied by compressor', 0))
            used_bytes = used_pages * page_size

            total_gb = total_bytes / (1024 ** 3)
            used_gb = used_bytes / (1024 ** 3)
            percent = (used_bytes / total_bytes) * 100
            return used_gb, total_gb, percent

        elif current_os == 'Windows':
            import ctypes

            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]

            mem_status = MEMORYSTATUSEX()
            mem_status.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(mem_status))

            total_gb = mem_status.ullTotalPhys / (1024 ** 3)
            avail_gb = mem_status.ullAvailPhys / (1024 ** 3)
            used_gb = total_gb - avail_gb
            percent = mem_status.dwMemoryLoad
            return used_gb, total_gb, percent

        elif current_os == 'Linux':
            meminfo = {}
            with open('/proc/meminfo', 'r') as f:
                for line in f:
                    parts = line.split(':')
                    if len(parts) == 2:
                        key = parts[0].strip()
                        value_kb = int(parts[1].strip().split(' ')[0])
                        meminfo[key] = value_kb

            total_kb = meminfo.get('MemTotal', 0)
            available_kb = meminfo.get('MemAvailable', 0)
            used_kb = total_kb - available_kb

            total_gb = total_kb / (1024 ** 2)
            used_gb = used_kb / (1024 ** 2)
            percent = (used_kb / total_kb) * 100 if total_kb else 0
            return used_gb, total_gb, percent

    except Exception:
        return None, None, None


def print_status_bar():
    used_gb, total_gb, percent = get_ram_usage()
    if used_gb is None:
        ram_str = 'RAM: unavailable'
    else:
        ram_str = f'RAM: {used_gb:.2f}GB / {total_gb:.2f}GB ({percent:.1f}%)'
    print(f'[STATUS] Tabs: {tabs_opened} | Windows: {windows_opened} | {ram_str}')


def open_new_window(browserChoice, url):
    if current_os == 'Darwin':
        if browserChoice == 1:  # Chrome
            script = f'''
            tell application "Google Chrome"
                make new window
                set URL of active tab of front window to "{url}"
            end tell
            '''
        else:  # Safari
            script = f'''
            tell application "Safari"
                make new document with properties {{URL:"{url}"}}
            end tell
            '''
        subprocess.run(['osascript', '-e', script], capture_output=True)

    elif current_os == 'Windows':
        if browserChoice == 1:  # Chrome
            subprocess.run(['start', '', 'chrome', '--new-window', url], shell=True)
        else:  # Edge
            subprocess.run(['start', '', 'msedge', '--new-window', url], shell=True)


def warm_up_browser(browserChoice):
    """Make sure the browser process is already running before opening real windows."""
    if current_os == 'Windows':
        if browserChoice == 1:
            subprocess.run(['start', '', 'chrome'], shell=True)
        else:
            subprocess.run(['start', '', 'msedge'], shell=True)
        time.sleep(2)


def open_new_tab(browserChoice, url):
    if current_os == 'Darwin':
        if browserChoice == 1:
            chrome.open_new_tab(url)
        else:
            safari.open_new_tab(url)
    elif current_os == 'Windows':
        if browserChoice == 1:
            subprocess.run(['start', '', 'chrome', url], shell=True)
        else:
            subprocess.run(['start', '', 'msedge', url], shell=True)


def open_script(tabs, windows, browserChoice):
    global tabs_opened, windows_opened

    if windows > 0:
        warm_up_browser(browserChoice)

    for w in range(windows):
        random_url = random.choice(url)
        open_new_window(browserChoice, random_url)
        windows_opened += 1
        time.sleep(0.75)

    for t in range(tabs):
        random_url = random.choice(url)
        open_new_tab(browserChoice, random_url)
        tabs_opened += 1
        time.sleep(0.75)

    print_status_bar()


def add_to_url_list():
    global url
    while True:
        new_url = input('Enter a URL to add (or type "done" to finish): ').strip()

        if new_url.lower() == 'done':
            break

        if not new_url.startswith('http://') and not new_url.startswith('https://'):
            print('Invalid URL — must start with http:// or https://')
            continue

        url.append(new_url)
        print(f'Added: {new_url}')

    print('')
    print('-' * 30)
    print('Current URL list:')
    for i, u in enumerate(url, start=1):
        print(f'[{i}] {u}')
    print('-' * 30)


while True:
    print('')
    print('-' * 30)
    print('Menu:')
    print('[1] Open tabs')
    print('[2] Open windows')
    print('[3] Open tabs + windows')
    print('[4] Add to url list')
    print('[5] Exit')
    print('-' * 30)
    print('')
    menuSelect = int(input('Select [1-5]: '))

    if menuSelect not in [1, 2, 3, 4, 5]:
        print('INVALID CHOICE.')
        continue

    if menuSelect == 1:
        tabs = int(input('How many tabs would you like to open? '))
        windows = 0
        open_script(tabs, windows, browserChoice)

    if menuSelect == 2:
        tabs = 0
        windows = int(input('How many windows would you like to open? '))
        open_script(tabs, windows, browserChoice)

    if menuSelect == 3:
        windows = int(input('How many windows would you like to open? '))
        tabs = int(input('How many tabs would you like to open? '))
        open_script(tabs, windows, browserChoice)

    if menuSelect == 4:
        add_to_url_list()

    if menuSelect == 5:
        print('Goodbye!')
        break